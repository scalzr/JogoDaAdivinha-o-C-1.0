﻿// See https://aka.ms/new-console-template for more information

using System;

namespace JogoAdivinhacao
{
    class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int numeroSecreto = random.Next(1, 101); // Gera um número entre 1 e 100
            int tentativas = 0;
            bool acertou = false;

            Console.WriteLine("Bem-vindo ao Jogo da Adivinhação!");
            Console.WriteLine("Tente adivinhar o número secreto entre 1 e 100.");

            while (!acertou)
            {
                tentativas++;
                Console.Write("Digite seu palpite: ");
                string input = Console.ReadLine();
                int palpite;

                if (int.TryParse(input, out palpite))
                {
                    if (palpite < 1 || palpite > 100)
                    {
                        Console.WriteLine("Por favor, digite um número entre 1 e 100.");
                    }
                    else if (palpite < numeroSecreto)
                    {
                        Console.WriteLine("Muito baixo! Tente novamente.");
                    }
                    else if (palpite > numeroSecreto)
                    {
                        Console.WriteLine("Muito alto! Tente novamente.");
                    }
                    else
                    {
                        Console.WriteLine($"Parabéns! Você adivinhou o número secreto em {tentativas} tentativas.");
                        acertou = true;
                    }
                }
                else
                {
                    Console.WriteLine("Entrada inválida. Por favor, digite um número.");
                }
            }
        }
    }
}

